<!DOCTYPE html>
<html>
<body>
    <?php
        $width = 2;
        $height = 3;
        $radius = 1;
        $pi = 3.14;
        
        $area = $pi * $radius *$radius;
        $rarea = $width * $height ;

        echo "AREA OS CIRCLE:" .$area. "<br>";
        echo "AREA OS CIRCLE:" .$rarea."<br>"



    ?>
</body>
</html>