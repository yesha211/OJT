<!DOCTYPE html>
<html>
<body>

    <?php
    echo "a:" .$a."<br>";
    echo "b: " .$b."<br>";
    echo "#arithmetic operation<br>";
     $a = 2;
     $b = 4;
     

     $sum = $a + $b ;
     $sub = $b - $a;
     $mul = $a * $b;
     $div = $b/$a;
     echo "sum: " . $sum. "<br>";
     echo "sub: " . $sub. "<br>";
     echo "mul: " . $mul. "<br>";
     echo "div: " . $div. "<br>";



    echo "#logical operator<br>";

     echo " a && b: " .($a && $b)."<br>";
     echo " a || b: " .($a || $b)."<br>";
     echo " a or b: " .($a or $b)."<br>";
     echo " a xor b:" .($a xor $b)."<br>";
    ?>


</body>
</html>
