<!DOCTYPE html>
<html>
<body>

<?php
    $name = "yesha";
    $enroll = "184";
    $dept = "B.tech IT";

    echo "my name is " . $name. "<br>";
    echo  "my enrollment no is " . $enroll. "<br>";
    echo "department: " . $dept. "<br>";
?>


</body>
</html>